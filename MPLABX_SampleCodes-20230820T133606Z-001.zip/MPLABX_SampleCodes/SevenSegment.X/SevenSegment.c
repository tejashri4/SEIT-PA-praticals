#include <xc.h>
//Configuration bit setting//
#pragma config OSC = HS //Oscillator Selection
#pragma config WDT = OFF //Disable Watchdog timer
#pragma config LVP = OFF //Disable Low Voltage Programming
#pragma config PBADEN = OFF //Disable PORTB Analog inputs


#define SegOne   0x0E
#define SegTwo   0x0D
#define SegThree 0x0B
#define SegFour  0x07	

void msdelay (unsigned int time);		//Function to generate delay


int main() {
    unsigned char  seg_code[]= {0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90,0x88,0x83,0xC6,0xA1,0x86,0x8E};
   
    int cnt, num, temp,i;

    /* Configure the ports as output */
    TRISB = 0x00; // Data lines
    TRISD = 0x00; // Control signal PORTD0-PORTD3    
    while (1) 
    {
        for (cnt = 0x00; cnt <= 9999; cnt++) // loop to display 0-9999
        {
            for (i = 0; i < 50; i++)
            {
                num = cnt;
                temp = num / 1000;
                num = num % 1000;
                PORTD = SegFour;
                PORTB = seg_code[temp];               
                msdelay(5);

                temp = num / 100;
                num = num % 100;
                PORTD = SegThree;
                PORTB = seg_code[temp];
                msdelay(5);

                temp = num / 10;
                PORTD = SegTwo; 
                PORTB = seg_code[temp];
                msdelay(5);

                temp = num % 10;
                PORTD = SegOne;
                PORTB = seg_code[temp];
                msdelay(5);                              
            }
        }
    }
}


//Function Definitions
void msdelay (unsigned int time) //Function to generate delay
{
unsigned int i, j;
  for (i = 0; i < time; i++)
	for (j = 0; j < 275; j++);//Calibrated for a 1 ms delay in MPLAB
}